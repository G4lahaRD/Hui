
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ggrer.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.ggrer.potion.UkpMobEffect;
import net.mcreator.ggrer.GgrerMod;

public class GgrerModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, GgrerMod.MODID);
	public static final RegistryObject<MobEffect> UKP = REGISTRY.register("ukp", () -> new UkpMobEffect());
}
